var name = prompt('Silakan ketik nama anda')
var dob = prompt('Silakan ketik tanggal lahir anda')
var address = prompt('Silakan ketik alamat lengkap anda')
var education = prompt('Silakan ketik jenjang pendidikan terakhir anda')

alert('Data berhasil disimpan.\nTerimakasih atas partisipasi anda')

console.log(`Nama: ${name}`)
console.log(`Tgl lahir: ${dob}`)
console.log(`Alamat: ${address}`)
console.log(`Pendidikan: ${education}`)
