const x = 4
const y = 3
const z = 2

const w = Math.pow((x + y * z) / (x * y), z)
console.log(w)
