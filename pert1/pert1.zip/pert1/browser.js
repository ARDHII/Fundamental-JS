// show alert on browser
alert('Hello there!')

// ask question
var myName = prompt('What is your name?')

// alert back with registered name
alert(`Good morning, ${myName}!`)

// write to html
document.write(`<h2>Good morning, ${myName}!</h2>`)
