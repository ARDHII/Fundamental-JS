// ini untuk print hello world
console.log('Hello world' + 'test')

// variabel
var name = 'Alven'
var hour = 10

// string concatenation (cara lama)
console.log('Hello ' + name + ', now is ' + hour + ' o\'clock')

// string literal/template literal (cara baru)
console.log(`Hello ${name}, now is ${hour} o'clock`)
